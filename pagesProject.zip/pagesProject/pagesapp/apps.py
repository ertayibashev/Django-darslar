from django.apps import AppConfig


class PagesappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pagesapp'
